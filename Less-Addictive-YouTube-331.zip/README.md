# Less Addicting YouTube
Remove some elements from Youtube to make it less addictive. Mix and match between the following options:
- Hide or show thumbnails and video preview
- Hide or show recommended videos sidebar
- Hide or show comments

