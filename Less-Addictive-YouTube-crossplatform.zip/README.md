# Less Addicting YouTube
 Remove addictive features from YT like thumbnails, comments, & previews
